# Emerging Market Stability Index

This project analyzes and visualizes the economic stability of emerging markets, providing a dashboard to explore key metrics and investment opportunities.

## How to Run This Project

### 1. Prerequisites

- Python 3.8+
- `pip` for package management

### 2. Setup

1.  **Download the Project**: Download the project files and unzip them into a new directory.

2.  **Navigate to the Project Directory**: Open a terminal or command prompt and navigate to the project's root directory:
    ```bash
    cd path/to/emerging-market-stability-index
    ```

3.  **Install Dependencies**: Install the required Python packages using the `requirements.txt` file:
    ```bash
    pip install -r requirements.txt
    ```

### 3. Running the Application

The project is divided into a data processing backend and a Streamlit dashboard. You must run the backend scripts first to generate the necessary data files.

1.  **Run the Data Pipeline**: Execute the following Python scripts in order from the `emerging-market-stability-index` directory. This will download the latest data and prepare it for the dashboard.

    ```bash
    python src/backend.py
    python src/data_pipeline.py
    python src/feature_engineering.py
    python src/model.py
    ```

2.  **Launch the Dashboard**: Once the data scripts have completed, you can start the Streamlit application:

    ```bash
    streamlit run src/dashboard.py
    ```

    After running this command, your web browser should open with the dashboard, typically at `http://localhost:8501`.

### Running in Google Colab

While this project is designed as a multi-file application, you can run the data processing steps in a Colab notebook. However, running the Streamlit dashboard directly in Colab requires some workarounds.

1.  **Upload Files**: Upload the entire `emerging-market-stability-index` directory to your Google Drive.

2.  **Mount Drive**: In a new Colab notebook, mount your Google Drive:
    ```python
    from google.colab import drive
    drive.mount('/content/drive')
    ```

3.  **Install Dependencies**:
    ```python
    !pip install -r /content/drive/My\ Drive/emerging-market-stability-index/requirements.txt
    ```

4.  **Run Data Pipeline**: You can execute the data scripts from the notebook:
    ```python
    !python /content/drive/My\ Drive/emerging-market-stability-index/src/backend.py
    !python /content/drive/My\ Drive/emerging-market-stability-index/src/data_pipeline.py
    !python /content/drive/My\ Drive/emerging-market-stability-index/src/feature_engineering.py
    !python /content/drive/My\ Drive/emerging-market-stability-index/src/model.py
    ```

5.  **Running Streamlit**: To run the Streamlit app, you'll need to use a tool like `ngrok` to expose the service to the web. This is more advanced and may be less stable than running it locally.